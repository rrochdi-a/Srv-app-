# بناء ملف AAB

1. أنشئ مستودعاً خاصاً على GitHub وارفع محتويات هذا المجلد (www, package.json, capacitor.config.json, .github).
2. أنشئ مفتاح التوقيع (مرة واحدة، واحتفظ به دائماً):
   keytool -genkeypair -v -keystore upload.jks -keyalg RSA -keysize 2048 -validity 10000 -alias upload
   ثم: base64 -w0 upload.jks
3. في GitHub: Settings → Secrets → Actions، أضف:
   KEYSTORE_BASE64 (ناتج base64) ، KEYSTORE_PASSWORD ، KEY_ALIAS (مثلاً upload)
4. غيّر appId في capacitor.config.json إلى معرّف فريد خاص بك (مثل com.اسمك.school).
5. من تبويب Actions شغّل Build AAB، ثم نزّل app-release-aab.
6. ارفع الملف في Google Play Console (يلزم حساب مطوّر 25$).

## ما أُضيف للأندرويد
- www/native-bridge.js: الطباعة (نافذة طباعة أندرويد / حفظ PDF)، حفظ ومشاركة ملفات Excel وPDF وCSV، ونسخة احتياطية تلقائية للتخزين المحلي (تُسترجع إن فُرّغ التخزين).
- scripts/setup-android.js: يضيف مكوّن الطباعة الأصلي أثناء البناء.
