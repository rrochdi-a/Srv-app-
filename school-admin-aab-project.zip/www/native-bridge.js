/* جسر أندرويد: الطباعة + حفظ/مشاركة الملفات + نسخة احتياطية للتخزين المحلي. يعمل فقط داخل تطبيق Capacitor. */
(function(){
  var C=window.Capacitor;
  if(!C||!C.isNativePlatform||!C.isNativePlatform())return;
  var cache={};
  function plug(n){return cache[n]||(cache[n]=(C.Plugins&&C.Plugins[n])||C.registerPlugin(n));}

  /* ---------- 1) الطباعة ---------- */
  function snapshot(){
    var styles=[].map.call(document.querySelectorAll('style'),function(s){return s.outerHTML;}).join('\n');
    var clone=document.body.cloneNode(true);
    [].forEach.call(clone.querySelectorAll('script'),function(n){n.remove();});
    var o=document.body.querySelectorAll('input,select,textarea'),c=clone.querySelectorAll('input,select,textarea');
    for(var i=0;i<o.length&&i<c.length;i++){
      var a=o[i],b=c[i];
      if(a.tagName==='SELECT'){[].forEach.call(b.options,function(op,k){if(a.options[k]&&a.options[k].selected)op.setAttribute('selected','');else op.removeAttribute('selected');});}
      else if(a.tagName==='TEXTAREA'){b.textContent=a.value;}
      else if(a.type==='checkbox'||a.type==='radio'){if(a.checked)b.setAttribute('checked','');else b.removeAttribute('checked');}
      else b.setAttribute('value',a.value);
    }
    var m,re=/size:\s*A4\s+(landscape|portrait)/gi,land=false;
    while((m=re.exec(styles)))land=/landscape/i.test(m[1]);
    var html='<!doctype html><html dir="rtl" lang="ar" class="'+document.documentElement.className+'"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">'+styles+'</head><body class="'+document.body.className+'">'+clone.innerHTML+'</body></html>';
    return {html:html,landscape:land};
  }
  window.print=function(){
    try{
      var s=snapshot();
      plug('AppPrint').print({html:s.html,landscape:s.landscape,name:(document.title||'document').slice(0,60)})
        .catch(function(e){alert('تعذرت الطباعة: '+(e&&e.message||e));})
        .then(function(){setTimeout(function(){window.dispatchEvent(new Event('afterprint'));},300);});
    }catch(e){alert('تعذرت الطباعة: '+e.message);}
  };

  /* ---------- 2) حفظ / مشاركة الملفات المنزَّلة ---------- */
  var blobs={},origCreate=URL.createObjectURL;
  URL.createObjectURL=function(b){var u=origCreate.call(URL,b);try{blobs[u]=b;}catch(e){}return u;};
  function toBase64(blob){return new Promise(function(res,rej){var r=new FileReader();r.onload=function(){var s=String(r.result);res(s.slice(s.indexOf(',')+1));};r.onerror=rej;r.readAsDataURL(blob);});}
  function safeName(n){return String(n||'file').replace(/[\\\/:*?"<>|]+/g,'_').slice(0,100)||'file';}
  function saveAndShare(href,name){
    var get=blobs[href]?Promise.resolve(blobs[href]):fetch(href).then(function(r){return r.blob();});
    return get.then(toBase64).then(function(b64){
      name=safeName(name);
      return plug('Filesystem').writeFile({path:name,data:b64,directory:'CACHE'}).then(function(r){
        return plug('Share').share({title:name,url:r.uri,dialogTitle:'حفظ / إرسال الملف'});
      });
    }).catch(function(e){if(e&&/cancel/i.test(e.message||''))return;alert('تعذر حفظ الملف: '+(e&&e.message||e));});
  }
  function isDl(a){return a&&a.tagName==='A'&&a.hasAttribute('download')&&/^(blob:|data:)/.test(a.href||'');}
  var oc=HTMLAnchorElement.prototype.click;
  HTMLAnchorElement.prototype.click=function(){if(isDl(this)){saveAndShare(this.href,this.download);return;}return oc.apply(this,arguments);};
  var od=EventTarget.prototype.dispatchEvent;
  EventTarget.prototype.dispatchEvent=function(ev){if(ev&&ev.type==='click'&&isDl(this)){saveAndShare(this.href,this.download);return true;}return od.apply(this,arguments);};
  document.addEventListener('click',function(e){var a=e.target&&e.target.closest&&e.target.closest('a[download]');if(isDl(a)){e.preventDefault();saveAndShare(a.href,a.download);}},true);

  /* ---------- 3) التخزين المحلي: طلب الاستمرارية + نسخة احتياطية تلقائية ---------- */
  try{if(navigator.storage&&navigator.storage.persist)navigator.storage.persist();}catch(e){}
  var BK='school_backup.json',timer=null;
  function writeBackup(){
    try{
      var o={};for(var i=0;i<localStorage.length;i++){var k=localStorage.key(i);o[k]=localStorage.getItem(k);}
      plug('Filesystem').writeFile({path:BK,data:JSON.stringify(o),directory:'DATA',encoding:'utf8'}).catch(function(){});
    }catch(e){}
  }
  function sched(){clearTimeout(timer);timer=setTimeout(writeBackup,2500);}
  var sp=Storage.prototype,si=sp.setItem,sr=sp.removeItem,sc=sp.clear;
  sp.setItem=function(){var r=si.apply(this,arguments);if(this===window.localStorage)sched();return r;};
  sp.removeItem=function(){var r=sr.apply(this,arguments);if(this===window.localStorage)sched();return r;};
  sp.clear=function(){var r=sc.apply(this,arguments);return r;};
  document.addEventListener('visibilitychange',function(){if(document.hidden){clearTimeout(timer);writeBackup();}});
  // استرجاع تلقائي إذا فُرّغ التخزين (مثلاً مسح بيانات WebView)
  try{
    if(localStorage.length===0&&!sessionStorage.getItem('__restored')){
      sessionStorage.setItem('__restored','1');
      plug('Filesystem').readFile({path:BK,directory:'DATA',encoding:'utf8'}).then(function(r){
        var o=JSON.parse(r.data||'{}'),n=0;
        Object.keys(o).forEach(function(k){si.call(localStorage,k,o[k]);n++;});
        if(n)location.reload();
      }).catch(function(){});
    }else{setTimeout(writeBackup,4000);}
  }catch(e){}
})();
