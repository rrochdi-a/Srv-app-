// يُنفَّذ بعد "cap add android": يضيف مكوّن الطباعة الأصلي ويسجله في MainActivity
const fs=require('fs'),path=require('path');
const cfg=JSON.parse(fs.readFileSync('capacitor.config.json','utf8'));
const pkg=cfg.appId;
const dir=path.join('android','app','src','main','java',...pkg.split('.'));
fs.mkdirSync(dir,{recursive:true});
fs.writeFileSync(path.join(dir,'AppPrintPlugin.java'),`package ${pkg};

import android.content.Context;
import android.print.PrintAttributes;
import android.print.PrintDocumentAdapter;
import android.print.PrintManager;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;

@CapacitorPlugin(name = "AppPrint")
public class AppPrintPlugin extends Plugin {
    private static WebView keep;

    @PluginMethod
    public void print(final PluginCall call) {
        final String html = call.getString("html", "");
        final boolean land = Boolean.TRUE.equals(call.getBoolean("landscape", false));
        final String name = call.getString("name", "document");
        getActivity().runOnUiThread(new Runnable() {
            @Override public void run() {
                final WebView wv = new WebView(getActivity());
                keep = wv;
                wv.setWebViewClient(new WebViewClient() {
                    @Override public void onPageFinished(WebView v, String url) {
                        PrintManager pm = (PrintManager) getActivity().getSystemService(Context.PRINT_SERVICE);
                        PrintDocumentAdapter ad = v.createPrintDocumentAdapter(name);
                        PrintAttributes.MediaSize ms = land ? PrintAttributes.MediaSize.ISO_A4.asLandscape() : PrintAttributes.MediaSize.ISO_A4.asPortrait();
                        PrintAttributes attrs = new PrintAttributes.Builder()
                            .setMediaSize(ms)
                            .setMinMargins(PrintAttributes.Margins.NO_MARGINS)
                            .build();
                        pm.print(name, ad, attrs);
                        call.resolve();
                    }
                });
                wv.loadDataWithBaseURL("https://localhost/", html, "text/html", "UTF-8", null);
            }
        });
    }
}
`);
fs.writeFileSync(path.join(dir,'MainActivity.java'),`package ${pkg};

import android.os.Bundle;
import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {
    @Override
    public void onCreate(Bundle savedInstanceState) {
        registerPlugin(AppPrintPlugin.class);
        super.onCreate(savedInstanceState);
    }
}
`);
console.log('native print plugin written to',dir);
